Lumvia Luxe — Ready-to-use Website Package

Files included:
- index.html
- styles.css
- logo.svg
- product1.svg, product2.svg, product3.svg

How to use:
1. Download and unzip the package.
2. Open index.html in your browser to preview locally.
3. To publish online:
   - Option A: Upload files to Netlify (drag-and-drop) — instant site URL.
   - Option B: Push to GitHub and enable GitHub Pages on the repository (use main branch / docs folder).
   - Option C: Upload to any shared hosting or your own server.

WhatsApp links are pre-filled to +91 9664450485. Edit index.html to change content, prices or product text.

Need me to publish this for you (connect to GitHub/Netlify)? I can guide step-by-step.
